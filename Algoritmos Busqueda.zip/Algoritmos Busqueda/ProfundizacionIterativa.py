def cargar_grafo(nombre_archivo):
    grafo = {}
    with open(nombre_archivo, 'r') as archivo:
        for linea in archivo:
            partes = linea.strip().split()
            if not partes:
                continue
            ciudad = partes[0]
            vecinos = []
            for item in partes[1:]:
                vecino, costo = item.split(':')
                vecinos.append((vecino, int(costo)))
            grafo[ciudad] = vecinos
    return grafo

def dls(grafo, nodo, objetivo, limite, ruta, visitados):
    ruta.append(nodo)
    visitados.add(nodo)

    if nodo == objetivo:
        return ruta

    if limite <= 0:
        ruta.pop()
        return None

    for vecino, _ in grafo.get(nodo, []):
        if vecino not in visitados:
            resultado = dls(grafo, vecino, objetivo, limite - 1, ruta, visitados)
            if resultado:
                return resultado

    ruta.pop()
    return None

def iddfs(grafo, inicio, objetivo, limite_maximo):
    for limite in range(limite_maximo + 1):
        ruta = []
        visitados = set()
        resultado = dls(grafo, inicio, objetivo, limite, ruta, visitados)
        if resultado:
            return resultado
    return None

def main():
    grafo = cargar_grafo('ciudades.txt')

    print("Ciudades disponibles:", ', '.join(sorted(grafo.keys())))
    inicio = input("Ciudad de inicio: ").strip().capitalize()
    objetivo = input("Ciudad destino: ").strip().capitalize()
    limite_maximo = int(input("Límite máximo de profundidad: "))

    if inicio not in grafo or objetivo not in grafo:
        print("Error: Ciudad no encontrada en el mapa.")
        return

    camino = iddfs(grafo, inicio, objetivo, limite_maximo)

    if camino:
        print("Camino encontrado:", ' -> '.join(camino))
    else:
        print(f"No se encontró un camino dentro del límite de profundidad {limite_maximo}.")

if __name__ == "__main__":
    main()
