import random
import math
from collections import Counter

# Cargar el dataset iris.data
def cargar_datos(path):
    datos = []
    with open(path, 'r') as archivo:
        for linea in archivo:
            partes = linea.strip().split(',')
            if len(partes) == 5:  # 4 atributos + clase
                atributos = list(map(float, partes[:4]))
                clase = partes[4]
                datos.append((atributos, clase))
    return datos

# Cálculo de distancia Euclidiana
def distancia_euclidiana(a, b):
    return math.sqrt(sum((x - y) ** 2 for x, y in zip(a, b)))

# Clasificador k-NN
def knn(entrenamiento, punto, k):
    distancias = [(distancia_euclidiana(punto, datos[0]), datos[1]) for datos in entrenamiento]
    distancias.sort(key=lambda x: x[0])
    vecinos = [clase for _, clase in distancias[:k]]
    return Counter(vecinos).most_common(1)[0][0]

# Evaluación del modelo
def evaluar_knn(datos, k):
    random.shuffle(datos)
    corte = int(0.8 * len(datos))
    entrenamiento = datos[:corte]
    prueba = datos[corte:]

    aciertos = 0
    for punto, clase_real in prueba:
        clase_predicha = knn(entrenamiento, punto, k)
        if clase_predicha == clase_real:
            aciertos += 1

    total = len(prueba)
    exactitud = aciertos / total
    error = 1 - exactitud
    return aciertos, total - aciertos, exactitud, error

# MAIN
if __name__ == "__main__":
    datos = cargar_datos("iris.data")

    print("k | Aciertos | Errores | Exactitud | Error")
    for k in range(1, 16):
        aciertos, errores, exactitud, error = evaluar_knn(datos, k)
        print(f"{k:2} | {aciertos:8} | {errores:7} | {exactitud:.4f}   | {error:.4f}")
