
import heapq
from collections import deque
import networkx as nx
import matplotlib.pyplot as plt
import math

# ---------- Cargar grafo desde txt ----------
def cargar_grafo(nombre_archivo):
    grafo = {}
    with open(nombre_archivo, 'r', encoding='utf-8') as archivo:
        for linea in archivo:
            partes = linea.strip().split()
            if partes:
                ciudad = partes[0]
                vecinos = []
                for item in partes[1:]:
                    vecino, costo = item.split(':')
                    vecinos.append((vecino, int(costo)))
                grafo[ciudad] = vecinos
    return grafo

# ---------- Cargar coordenadas ----------
def cargar_coordenadas(nombre_archivo):
    coords = {}
    with open(nombre_archivo, 'r', encoding='utf-8') as archivo:
        for linea in archivo:
            partes = linea.strip().split()
            if len(partes) == 3:
                ciudad, x, y = partes
                coords[ciudad] = (float(x), float(y))
    return coords

def distancia_euclidiana(coord1, coord2):
    x1, y1 = coord1
    x2, y2 = coord2
    return math.sqrt((x2 - x1)**2 + (y2 - y1)**2)

# ---------- Visualizar grafo ----------
def visualizar_grafo(grafo, ruta=None, titulo="Grafo"):
    G = nx.Graph()
    for nodo in grafo:
        for vecino, peso in grafo[nodo]:
            G.add_edge(nodo, vecino, weight=peso)

    pos = nx.spring_layout(G)
    plt.figure(figsize=(10, 7))
    nx.draw(G, pos, with_labels=True, node_size=600, node_color="lightblue", font_size=9)
    nx.draw_networkx_edge_labels(G, pos, edge_labels=nx.get_edge_attributes(G, 'weight'))

    if ruta:
        edges = list(zip(ruta, ruta[1:]))
        nx.draw_networkx_edges(G, pos, edgelist=edges, edge_color='red', width=2)

    plt.title(titulo)
    plt.axis('off')
    plt.show(block=False)

# ---------- Algoritmos ----------
def bfs(grafo, inicio, objetivo):
    visitados = set()
    cola = deque([[inicio]])
    while cola:
        ruta = cola.popleft()
        nodo = ruta[-1]
        if nodo == objetivo:
            return ruta
        if nodo not in visitados:
            visitados.add(nodo)
            for vecino, _ in grafo[nodo]:
                nueva_ruta = list(ruta)
                nueva_ruta.append(vecino)
                cola.append(nueva_ruta)
    return None

def dfs(grafo, inicio, objetivo):
    pila = [[inicio]]
    visitados = set()
    while pila:
        ruta = pila.pop()
        nodo = ruta[-1]
        if nodo == objetivo:
            return ruta
        if nodo not in visitados:
            visitados.add(nodo)
            for vecino, _ in reversed(grafo[nodo]):
                nueva_ruta = list(ruta)
                nueva_ruta.append(vecino)
                pila.append(nueva_ruta)
    return None

def busqueda_avara(grafo, coordenadas, inicio, objetivo):
    visitados = set()
    cola = []
    heur_inicial = distancia_euclidiana(coordenadas[inicio], coordenadas[objetivo])
    heapq.heappush(cola, (heur_inicial, [inicio]))

    while cola:
        _, ruta = heapq.heappop(cola)
        nodo = ruta[-1]
        if nodo == objetivo:
            return ruta
        if nodo not in visitados:
            visitados.add(nodo)
            for vecino, _ in grafo.get(nodo, []):
                if vecino not in visitados:
                    nueva_ruta = list(ruta)
                    nueva_ruta.append(vecino)
                    heur = distancia_euclidiana(coordenadas[vecino], coordenadas[objetivo])
                    heapq.heappush(cola, (heur, nueva_ruta))
    return None

def busqueda_costo_uniforme(grafo, inicio, objetivo):
    cola = []
    heapq.heappush(cola, (0, [inicio]))
    visitados = set()
    while cola:
        costo_actual, ruta = heapq.heappop(cola)
        nodo = ruta[-1]
        if nodo == objetivo:
            return ruta, costo_actual
        if nodo not in visitados:
            visitados.add(nodo)
            for vecino, costo in grafo.get(nodo, []):
                if vecino not in visitados:
                    nueva_ruta = list(ruta)
                    nueva_ruta.append(vecino)
                    heapq.heappush(cola, (costo_actual + costo, nueva_ruta))
    return None, None

# ---------- Menú ----------
def mostrar_menu(opciones, titulo):
    print(f"\n=== {titulo} ===")
    for i, opcion in enumerate(opciones):
        print(f"{i + 1}. {opcion}")
    while True:
        eleccion = input("Elige una opción: ")
        if eleccion.isdigit() and 1 <= int(eleccion) <= len(opciones):
            return opciones[int(eleccion) - 1]
        else:
            print("Opción inválida. Intenta nuevamente.")

# ---------- Programa principal ----------
def main():
    while True:
        grafos_disponibles = ['ciudades.txt', 'vuelos.txt', 'historia.txt']
        algoritmos = ['BFS', 'DFS', 'Avara', 'Costo Uniforme']
        archivos_coords = {
            'ciudades.txt': 'coordenadas.txt',
            'vuelos.txt': 'coordenadas_vuelos.txt',
            'historia.txt': 'coordenadas_historia.txt'
        }

        grafo_archivo = mostrar_menu(grafos_disponibles, "Selecciona un grafo")
        algoritmo = mostrar_menu(algoritmos, "Selecciona el algoritmo de búsqueda")
        grafo = cargar_grafo(grafo_archivo)
        visualizar_grafo(grafo, titulo=f"Grafo: {grafo_archivo}")

        inicio = input("Nodo de inicio: ").strip()
        objetivo = input("Nodo destino: ").strip()

        if inicio not in grafo or objetivo not in grafo:
            print("Nodo no encontrado en el grafo.")
            continue

        if algoritmo == 'BFS':
            ruta = bfs(grafo, inicio, objetivo)
            if ruta:
                print("Ruta encontrada (BFS):", ' -> '.join(ruta))
                visualizar_grafo(grafo, ruta, "Ruta encontrada con BFS")
                input("Presiona ENTER para continuar...")
            else:
                print("No se encontró camino.")

        elif algoritmo == 'DFS':
            ruta = dfs(grafo, inicio, objetivo)
            if ruta:
                print("Ruta encontrada (DFS):", ' -> '.join(ruta))
                visualizar_grafo(grafo, ruta, "Ruta encontrada con DFS")
                input("Presiona ENTER para continuar...")
            else:
                print("No se encontró camino.")

        elif algoritmo == 'Avara':
            coords_file = archivos_coords.get(grafo_archivo)
            if not coords_file:
                print("No se encontró archivo de coordenadas.")
                continue
            coordenadas = cargar_coordenadas(coords_file)
            if inicio not in coordenadas or objetivo not in coordenadas:
                print("Faltan coordenadas para los nodos seleccionados.")
                continue
            ruta = busqueda_avara(grafo, coordenadas, inicio, objetivo)
            if ruta:
                print("Ruta encontrada (Avara):", ' -> '.join(ruta))
                visualizar_grafo(grafo, ruta, "Ruta encontrada con Avara")
                input("Presiona ENTER para continuar...")
            else:
                print("No se encontró camino.")

        elif algoritmo == 'Costo Uniforme':
            ruta, costo = busqueda_costo_uniforme(grafo, inicio, objetivo)
            if ruta:
                print("Ruta encontrada (UCS):", ' -> '.join(ruta))
                print("Costo total:", costo)
                visualizar_grafo(grafo, ruta, "Ruta encontrada con Costo Uniforme")
                input("Presiona ENTER para continuar...")
            else:
                print("No se encontró camino.")

        repetir = input("\n¿Deseas realizar otra búsqueda? (s/n): ").strip().lower()
        if repetir != 's':
            print("Gracias por usar el sistema. ¡Hasta pronto!")
            break

if __name__ == "__main__":
    main()
