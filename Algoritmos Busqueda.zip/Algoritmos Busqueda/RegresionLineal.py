import numpy as np
from sklearn.linear_model import LinearRegression

# Datos
X = np.array([[-1], [0], [1], [2], [3], [4]])  # ¡Debe ser 2D!
y = np.array([-3, -1, 1, 3, 5, 7])

# Modelo
modelo = LinearRegression()
modelo.fit(X, y)

# Resultados
m = modelo.coef_[0]
b = modelo.intercept_

print(f"Regla encontrada por Scikit-learn: y = {m:.2f}x + {b:.2f}")
