import heapq
import math

def cargar_grafo(nombre_archivo):
    grafo = {}
    with open(nombre_archivo, 'r') as archivo:
        for linea in archivo:
            partes = linea.strip().split()
            if partes:
                ciudad = partes[0]
                vecinos = []
                for item in partes[1:]:
                    vecino, costo = item.split(':')
                    vecinos.append((vecino, int(costo)))
                grafo[ciudad] = vecinos
    return grafo

def cargar_coordenadas(nombre_archivo):
    coords = {}
    with open(nombre_archivo, 'r') as archivo:
        for linea in archivo:
            partes = linea.strip().split()
            if len(partes) == 3:
                ciudad, x, y = partes
                coords[ciudad] = (float(x), float(y))
    return coords

def distancia_euclidiana(coord1, coord2):
    x1, y1 = coord1
    x2, y2 = coord2
    return math.sqrt((x2 - x1)**2 + (y2 - y1)**2)

def calcular_costo_ruta(grafo, ruta):
    costo_total = 0
    for i in range(len(ruta) - 1):
        actual = ruta[i]
        siguiente = ruta[i + 1]
        for vecino, costo in grafo[actual]:
            if vecino == siguiente:
                costo_total += costo
                break
    return costo_total

def busqueda_avara(grafo, coordenadas, inicio, objetivo):
    visitados = set()
    cola = []
    heur_inicial = distancia_euclidiana(coordenadas[inicio], coordenadas[objetivo])
    print (heur_inicial)
    heapq.heappush(cola, (heur_inicial, [inicio]))

    while cola:
        _, ruta = heapq.heappop(cola)
        nodo = ruta[-1]

        if nodo == objetivo:
            return ruta

        if nodo not in visitados:
            visitados.add(nodo)
            for vecino, _ in grafo.get(nodo, []):
                if vecino not in visitados:
                    nueva_ruta = list(ruta)
                    nueva_ruta.append(vecino)
                    heur = distancia_euclidiana(coordenadas[vecino], coordenadas[objetivo])
                    print (heur)
                    heapq.heappush(cola, (heur, nueva_ruta))

    return None

def main():
    grafo = cargar_grafo('ciudades.txt')
    coordenadas = cargar_coordenadas('coordenadas.txt')

    print("Ciudades disponibles:", ', '.join(sorted(grafo.keys())))
    inicio = input("Ciudad de inicio: ").strip().capitalize()
    objetivo = input("Ciudad destino: ").strip().capitalize()

    if inicio not in grafo or objetivo not in grafo:
        print("Error: Ciudad no encontrada en el mapa.")
        return

    camino = busqueda_avara(grafo, coordenadas, inicio, objetivo)

    if camino:
        costo = calcular_costo_ruta(grafo, camino)
        print("Camino encontrado (Avara con Euclidiana):", ' -> '.join(camino))
        print("Costo total del camino:", costo)
    else:
        print("No se encontró un camino.")

if __name__ == "__main__":
    main()
