from collections import deque

def cargar_grafo(nombre_archivo):
    grafo = {}
    with open(nombre_archivo, 'r') as archivo:
        for linea in archivo:
            partes = linea.strip().split()
            if not partes:
                continue
            ciudad = partes[0]
            vecinos = []
            for item in partes[1:]:
                vecino, costo = item.split(':')
                vecinos.append((vecino, int(costo)))
            grafo[ciudad] = vecinos
    return grafo

def bfs(grafo, inicio, objetivo):
    visitados = set()
    cola = deque([[inicio]])

    while cola:
        ruta = cola.popleft()
        print("Ruta:",ruta)
        nodo = ruta[-1]
        print("nodo:",nodo)
        if nodo == objetivo:
            return ruta

        if nodo not in visitados:
            visitados.add(nodo)
            for vecino, _ in grafo.get(nodo, []):
                nueva_ruta = list(ruta)
                nueva_ruta.append(vecino)
                print("nueva ruta: ",nueva_ruta)
                cola.append(nueva_ruta)
                print("Cola:",cola)

    return None

def main():
    grafo = cargar_grafo('ciudades.txt')

    print("Ciudades disponibles:", ', '.join(sorted(grafo.keys())))
    inicio = input("Ciudad de inicio: ").strip().capitalize()
    objetivo = input("Ciudad destino: ").strip().capitalize()

    if inicio not in grafo or objetivo not in grafo:
        print("Error: Ciudad no encontrada en el mapa.")
        return

    camino = bfs(grafo, inicio, objetivo)

    if camino:
        print("Camino encontrado:", ' -> '.join(camino))
    else:
        print("No se encontró un camino.")

if __name__ == "__main__":
    main()
