import heapq

def cargar_grafo(nombre_archivo):
    grafo = {}
    with open(nombre_archivo, 'r') as archivo:
        for linea in archivo:
            partes = linea.strip().split()
            if partes:
                ciudad = partes[0]
                vecinos = []
                for item in partes[1:]:
                    vecino, costo = item.split(':')
                    vecinos.append((vecino, int(costo)))
                grafo[ciudad] = vecinos
    return grafo

def cargar_heuristica(nombre_archivo):
    heuristica = {}
    with open(nombre_archivo, 'r') as archivo:
        for linea in archivo:
            partes = linea.strip().split()
            if len(partes) == 2:
                ciudad, valor = partes
                heuristica[ciudad] = int(valor)
    return heuristica

def calcular_costo_ruta(grafo, ruta):
    costo_total = 0
    for i in range(len(ruta) - 1):
        actual = ruta[i]
        siguiente = ruta[i + 1]
        for vecino, costo in grafo[actual]:
            if vecino == siguiente:
                costo_total += costo
                break
    return costo_total

def busqueda_a_estrella(grafo, heuristica, inicio, objetivo):
    cola = []
    heapq.heappush(cola, (heuristica[inicio], 0, [inicio]))  # (f = g + h, g, ruta)
    visitados = set()
    print("COLA:   ",cola)
    while cola:
        f_actual, costo_actual, ruta = heapq.heappop(cola)
        print("F:   ", f_actual)
        print("costo:   ", costo_actual)
        print("ruta:   ", ruta)
        nodo = ruta[-1]
        print("NODO: ", nodo)
        if nodo == objetivo:
            return ruta, costo_actual

        if nodo not in visitados:
            visitados.add(nodo)
            for vecino, costo in grafo.get(nodo, []):
                if vecino not in visitados:
                    nuevo_costo = costo_actual + costo
                    f = nuevo_costo + heuristica.get(vecino, float('inf'))
                    nueva_ruta = list(ruta)
                    nueva_ruta.append(vecino)
                    heapq.heappush(cola, (f, nuevo_costo, nueva_ruta))

    return None, None

def main():
    grafo = cargar_grafo('ciudades.txt')
    heuristica = cargar_heuristica('heuristica.txt')

    print("Ciudades disponibles:", ', '.join(sorted(grafo.keys())))
    inicio = input("Ciudad de inicio: ").strip().capitalize()
    objetivo = input("Ciudad destino: ").strip().capitalize()

    if inicio not in grafo or objetivo not in grafo:
        print("Error: Ciudad no encontrada en el mapa.")
        return

    camino, costo_total = busqueda_a_estrella(grafo, heuristica, inicio, objetivo)

    if camino:
        print("Camino encontrado (A*):", ' -> '.join(camino))
        print("Costo total del camino:", costo_total)
    else:
        print("No se encontró un camino.")

if __name__ == "__main__":
    main()
