import heapq

def cargar_grafo(nombre_archivo):
    grafo = {}
    with open(nombre_archivo, 'r') as archivo:
        for linea in archivo:
            partes = linea.strip().split()
            if not partes:
                continue
            ciudad = partes[0]
            vecinos = []
            for item in partes[1:]:
                vecino, costo = item.split(':')
                vecinos.append((vecino, int(costo)))
            grafo[ciudad] = vecinos
    return grafo

def ucs(grafo, inicio, objetivo):
    cola = [(0, inicio, [inicio])]  
    visitados = set()

    while cola:
        costo_actual, ciudad_actual, ruta = heapq.heappop(cola)
        print("")
        if ciudad_actual == objetivo:
            return ruta, costo_actual

        if ciudad_actual in visitados:
            continue
        visitados.add(ciudad_actual)

        for vecino, costo in grafo.get(ciudad_actual, []):
            if vecino not in visitados:
                heapq.heappush(cola, (costo_actual + costo, vecino, ruta + [vecino]))
                print("cola:", cola)

    return None, float('inf')

def main():
    grafo = cargar_grafo('ciudades.txt')

    print("Ciudades disponibles:", ', '.join(sorted(grafo.keys())))
    inicio = input("Ciudad de inicio: ").strip().capitalize()
    objetivo = input("Ciudad destino: ").strip().capitalize()

    if inicio not in grafo or objetivo not in grafo:
        print("Error: Ciudad no encontrada en el mapa.")
        return

    ruta, costo_total = ucs(grafo, inicio, objetivo)

    if ruta:
        print(f"Camino encontrado: {' -> '.join(ruta)}")
        print(f"Costo total del camino: {costo_total}")
    else:
        print("No se encontró un camino.")

if __name__ == "__main__":
    main()
