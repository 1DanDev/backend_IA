import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score

# Cargar el archivo iris.data (debe estar junto al .py)
columnas = ['sepal_length', 'sepal_width', 'petal_length', 'petal_width', 'class']
df = pd.read_csv('iris.data', header=None, names=columnas)

# Eliminar filas vacías (por si el archivo tiene líneas al final)
df.dropna(inplace=True)

# Variables independientes (X) y dependiente (y)
X = df[['sepal_width', 'petal_length', 'petal_width']]  # usamos 3 atributos
y = df['sepal_length']  # queremos predecir la longitud del sépalo

# Dividir en entrenamiento y prueba
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Crear y entrenar el modelo
modelo = LinearRegression()
modelo.fit(X_train, y_train)

# Predecir
y_pred = modelo.predict(X_test)

# Evaluar
print("Coeficientes:", modelo.coef_)
print("Intercepto:", modelo.intercept_)
print("MSE:", mean_squared_error(y_test, y_pred))
print("R²:", r2_score(y_test, y_pred))
