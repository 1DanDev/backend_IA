def cargar_grafo(nombre_archivo):
    grafo = {}
    with open(nombre_archivo, 'r') as archivo:
        for linea in archivo:
            partes = linea.strip().split()
            if not partes:
                continue
            ciudad = partes[0]
            vecinos = []
            for item in partes[1:]:
                vecino, costo = item.split(':')
                vecinos.append((vecino, int(costo)))
            grafo[ciudad] = vecinos
    return grafo

def dls(grafo, inicio, objetivo, limite):
    pila = [(inicio, [inicio], 0)]  # Tupla: (nodo_actual, ruta_actual, profundidad_actual)
    visitados = set()

    while pila:
        nodo, ruta, profundidad = pila.pop()

        if nodo == objetivo:
            return ruta

        if profundidad < limite:
            if nodo not in visitados:
                visitados.add(nodo)
                for vecino, _ in reversed(grafo.get(nodo, [])):
                    nueva_ruta = list(ruta)
                    nueva_ruta.append(vecino)
                    pila.append((vecino, nueva_ruta, profundidad + 1))

    return None

def main():
    grafo = cargar_grafo('ciudades.txt')

    print("Ciudades disponibles:", ', '.join(sorted(grafo.keys())))
    inicio = input("Ciudad de inicio: ").strip().capitalize()
    objetivo = input("Ciudad destino: ").strip().capitalize()
    limite = int(input("Límite de profundidad: "))

    if inicio not in grafo or objetivo not in grafo:
        print("Error: Ciudad no encontrada en el mapa.")
        return

    camino = dls(grafo, inicio, objetivo, limite)

    if camino:
        print("Camino encontrado:", ' -> '.join(camino))
    else:
        print(f"No se encontró un camino con límite de profundidad {limite}.")

if __name__ == "__main__":
    main()
