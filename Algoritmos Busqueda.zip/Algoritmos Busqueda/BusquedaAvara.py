import heapq

def cargar_grafo(nombre_archivo):
    grafo = {}
    with open(nombre_archivo, 'r') as archivo:
        for linea in archivo:
            partes = linea.strip().split()
            if partes:
                ciudad = partes[0]
                vecinos = []
                for item in partes[1:]:
                    vecino, costo = item.split(':')
                    vecinos.append((vecino, int(costo)))
                grafo[ciudad] = vecinos
    return grafo

def cargar_heuristica(nombre_archivo):
    heuristica = {}
    with open(nombre_archivo, 'r') as archivo:
        for linea in archivo:
            partes = linea.strip().split()
            if len(partes) == 2:
                ciudad, valor = partes
                heuristica[ciudad] = int(valor)
    return heuristica

def calcular_costo_ruta(grafo, ruta):
    costo_total = 0
    for i in range(len(ruta) - 1):
        actual = ruta[i]
        siguiente = ruta[i + 1]
        for vecino, costo in grafo[actual]:
            if vecino == siguiente:
                costo_total += costo
                break
    return costo_total

def busqueda_avara(grafo, heuristica, inicio, objetivo):
    visitados = set()
    cola = []
    heapq.heappush(cola, (heuristica[inicio], [inicio]))

    while cola:
        _, ruta = heapq.heappop(cola)
        nodo = ruta[-1]

        if nodo == objetivo:
            return ruta

        if nodo not in visitados:
            visitados.add(nodo)
            for vecino, _ in grafo.get(nodo, []):
                if vecino not in visitados:
                    nueva_ruta = list(ruta)
                    nueva_ruta.append(vecino)
                    heur = heuristica.get(vecino, float('inf'))
                    heapq.heappush(cola, (heur, nueva_ruta))

    return None

def main():
    grafo = cargar_grafo('ciudades.txt')
    heuristica = cargar_heuristica('heuristica.txt')

    print("Ciudades disponibles:", ', '.join(sorted(grafo.keys())))
    inicio = input("Ciudad de inicio: ").strip().capitalize()
    objetivo = input("Ciudad destino: ").strip().capitalize()

    if inicio not in grafo or objetivo not in grafo:
        print("Error: Ciudad no encontrada en el mapa.")
        return

    camino = busqueda_avara(grafo, heuristica, inicio, objetivo)

    if camino:
        costo = calcular_costo_ruta(grafo, camino)
        print("Camino encontrado (Avara):", ' -> '.join(camino))
        print("Costo total del camino:", costo)
    else:
        print("No se encontró un camino.")

if __name__ == "__main__":
    main()
